{
    'name': 'Spain E-Commerce',
    'depends': ['l10n_es', 'website_sale', 'account'],
    'data': [
        'data/ir_config_parameter.xml',
        'views/res_config_settings_views.xml',
    ],
    'post_init_hook': '_l10n_es_ecommerce_post_init_hook',
    'assets': {
        'web.assets_frontend': [],
        'web.assets_tests': []
    },
    'category': 'Customizations',
    'author': 'Odoo S.A.',
    'license': 'LGPL-3',
}

from . import controllers
from . import models

def _l10n_es_ecommerce_post_init_hook(env):
    env['ir.config_parameter'].sudo().set_float('l10n_es_ecommerce.simplified_invoice_limit', '400')

    existing = env['account.journal'].search([('code', '=', 'SINV')], limit=1)
    if not existing:
        env['account.journal'].create({
            'name': 'Simplified Journal',
            'code': 'SINV',
            'type': 'sale',
            'sequence': 100,
            'alias_name': 'purchase_expense',
        })
